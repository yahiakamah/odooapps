# -*- coding: utf-8 -*-
{
    'name': 'Add Oracle Field',
    'version': '1.0',
    'summary': 'Add Oracle Field',
    'sequence': -99,
    'description': """""",
    'category': 'Productivity',
    'author': 'Hussein Magdy',
    'maintainer': 'Hussein Magdy',
    'website': '',
    'license': 'AGPL-3',
    'depends': [
        'base','product'

    ],
    'data': ['views/view.xml'],
    'demo': [],
    'qweb': [],
    'images': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}
