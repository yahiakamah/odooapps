# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api

class ResPartner(models.Model):
    _inherit = "res.partner"
    partner_oracle_id=fields.Char("Customer Oracle ID")

    
class ProductProduct(models.Model):
    _inherit = "product.product"
    product_oracle_id=fields.Char("Product Oracle ID")

